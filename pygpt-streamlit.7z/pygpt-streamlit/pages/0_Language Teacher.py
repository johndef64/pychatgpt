from openai import OpenAI
import streamlit as st
from assistants import *

# General parameters
api_models = ['gpt-4o-mini', 'gpt-4o', 'gpt-4o-2024-08-06']

# Function to be executed on button click
def clearchat():
    st.session_state["messages_lang"] = [{"role": "system", "content": st.session_state.language_teacher}]
    st.write("Chat cleared!")

def remove_system_entries(input_list):
        return [entry for entry in input_list if entry.get('role') != 'system']
def update_teacher(input_list):
    updated_list = remove_system_entries(input_list)
    updated_list.append({"role": "system", "content": st.session_state.language_teacher})
    return updated_list

language_list  = ['none', 'Japanese','French','English', 'Portuguese', 'Italian', 'Chinese', 'Spanish']

if 'language' not in st.session_state:
    st.session_state['language'] = 'none'

# Sidebar code
with st.sidebar:
    if not st.session_state.openai_api_key:
        st.session_state.openai_api_key = st.text_input("OpenAI API Key", key="chatbot_api_key", type="password")
    else:
        st.markdown("[API key provided]")

    st.markdown("[Get an OpenAI API key](https://platform.openai.com/account/api-keys)")
    st.markdown("[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)")
    st.markdown("[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)")

    #model = st.selectbox("GPT model", ['gpt-3.5-turbo', 'gpt-4o'])
    model = st.radio('Choose a model:', api_models)

    #assistant = st.selectbox("Assistant", ['none', 'penrose', 'leonardo', 'mendel', 'darwin','delamain'])
    #language = st.selectbox("Language", language_list)
    get_language = st.selectbox("**Language**", language_list,
                                   index=language_list.index(st.session_state['language']))

    #st.markdown("Press Clearchat after Language selection")

    # Add a button in the sidebar and assign the function to be executed on click
    if st.button("Clearchat"):
        clearchat()

    uploaded_file = st.file_uploader("Upload an text file", type=("txt", "md"))
    #uploaded_image = st.file_uploader("Upload an image file", type=("png", "jpg"))
    image_url = st.text_input("Image Url")

if uploaded_file:
    text = uploaded_file.read().decode()
    st.session_state["messages_lang"].append({"role": "system", "content": "Read the text below and add it's content to your knowledge:\n\n"+text})

#if uploaded_file:
#image = uploaded_image.read().decode()
#st.session_state["messages_lang"] = ...


# Update session state with the selected value
st.session_state['language'] =    get_language

# Build assistant
st.session_state.language_teacher = create_language_teacher(st.session_state['language'])

st.title("💬 Language Teacher")
st.caption("🚀 Your GPT Teacher powered by OpenAI")
if "messages_lang" not in st.session_state:
    #st.session_state["messages_lang"] = [{"role": "assistant", "content": "How can I help you?"}]
    st.session_state["messages_lang"] = [{"role": "system", "content": st.session_state.language_teacher}]



# Update Language Automatically
#if st.session_state.persona not in st.session_state["messages_lang"]:
#    st.session_state["messages_lang"] = update_teacher(st.session_state["messages_lang"])


# Trigger the specific function based on the selection
#if assistant and not st.session_state["messages_lang"] == [{"role": "system", "content": assistants[assistant]}]:
#    st.session_state["messages_lang"] = [{"role": "system", "content": assistants[assistant]}]
#    #st.write('assistant changed')


for msg in st.session_state.messages_lang:
    if msg['role'] != 'system':
        if not isinstance(msg["content"], list):
            #if msg["role"] == 'user':
            #    avatar = user_avi
            #else:
            #    avatar = avatart_dict[assistant]
            st.chat_message(msg["role"]).write(msg["content"])


if prompt := st.chat_input():

    if not st.session_state.openai_api_key:
        st.info("Please add your OpenAI API key to continue.")
        st.stop()

    if image_url:
        image_add = {"role": 'user',
                     "content": [{"type": "image_url", "image_url": {"url": image_url} }] }
        if image_add not in st.session_state["messages_lang"]:
            st.session_state["messages_lang"].append(image_add)

    client = OpenAI(api_key=st.session_state.openai_api_key)
    st.session_state.messages_lang.append({"role": "user", "content": prompt})
    st.chat_message('user').write(prompt)
    response = client.chat.completions.create(model=model, messages=st.session_state.messages_lang)
    msg = response.choices[0].message.content
    #print(model)
    #print(msg)
    st.session_state.messages_lang.append({"role": "assistant", "content": msg})
    st.chat_message('assistant').write(msg)


#%%


