from openai import OpenAI
import streamlit as st
from assistants import *
import subprocess
import importlib
import platform
import base64
import re
import os
import io

def check_and_install_requirements(requirements):
    missing_requirements = []
    for module in requirements:
        try:
            # Check if the module is already installed
            importlib.import_module(module)
        except ImportError:
            missing_requirements.append(module)
    if len(missing_requirements) == 0:
        pass
    else:
        x = True#simple_bool(str(missing_requirements)+" are missing.\nWould you like to install them all?")
        if x:
            for module in missing_requirements:
                subprocess.check_call(["pip", "install", module])
                print(f"{module}' was installed correctly.")
        else:
            exit()

audio_requirements = ["sounddevice", "soundfile", "langdetect"]
def is_package_installed(package_name):
    try:
        output = subprocess.check_output("dpkg -l | grep " + package_name, shell=True)
        return bool(output)
    except subprocess.CalledProcessError:
        return False

linux_fix = False  # use linux_fix only if you are sudoer
is_linux =  platform.system() == "Linux"
if is_linux:
    if linux_fix:
        if not is_package_installed("libportaudio2"):
            subprocess.check_call(["sudo","apt-get", "update"])
            subprocess.check_call(["sudo","apt-get", "install", "libportaudio2"])

        check_and_install_requirements(audio_requirements)
        import soundfile as sf
        import sounddevice as sd

if not is_linux:
    check_and_install_requirements(audio_requirements)
    import soundfile as sf
    import sounddevice as sd

##### LANG ####
from langdetect import detect, DetectorFactory


def rileva_lingua(testo):
    # Reinizializzare il seed per ottenere risultati consistenti
    DetectorFactory.seed = 0

    # Mappa manuale dei codici delle lingue ai loro nomi completi
    language_map = {
        'en': 'English',
        'it': 'Italian',
        'fr': 'French',
        'de': 'German',
        'es': 'Spanish',
        'pt': 'Portuguese',
        'nl': 'Dutch',
        'ru': 'Russian',
        'zh-cn': 'Chinese (Simplified)',
        'ja': 'Japanese',
        # Aggiungere altre lingue se necessario
    }

    # Rileva la lingua del testo e la restituisce in formato esteso
    codice_lingua = detect(testo)
    return language_map.get(codice_lingua, 'Unknown')


# General Functions
def clearchat():
    st.session_state["messages"] = [{"role": "system", "content": st.session_state.persona}]
    st.session_state["messages_print"] = st.session_state["messages"]
    st.write("Chat cleared!")

def remove_system_entries(input_list):
    return [entry for entry in input_list if entry.get('role') != 'system']

def update_persona(input_list):
    updated_list = remove_system_entries(input_list)
    updated_list.append({"role": "system", "content": st.session_state.persona})
    return updated_list


def extract_foreign_sentences(input_text, language='english'): # DEPRECATED
    # Regular expressions pattern to match sentences in the specified language
    if language == 'japanese':
        pattern = r"[\u3000-\u303F\u3040-\u30FF\u4E00-\u9FAF\uFF01-\uFF5E\uFF0E\uFF1F]+[^()\n]*[。!?]"
        #re.match(r'^[\u3040-\u30FF\u4E00-\u9FFF]', s)
    elif language == 'french':
        pattern = r"[A-Z][^.]*[a-zA-Zéèàîêöùïüç]*\."
    elif language == 'italian':
        pattern = r"[A-ZÀÈÉÌÒÙ][^.]*[a-zA-Zàèéìòù]*\."
    elif language == 'spanish':
        pattern = r"[A-ZÁÉÍÓÚÑ][^.]*[a-zA-Záéíóúñ]*\."
    elif language == 'portuguese':
        pattern = r"[A-ZÁÉÍÓÚÃÕÉÍÂÊÔÇ][^.]*[a-zA-Záéíóúãõéíâêôç]*\."
    else:
        pattern = r"[A-Z][^.]*\."

    sentences = re.findall(pattern, input_text)

    # Filter out sentences containing '(' or ')'
    if language == 'japanese':
        sentences = [sentence for sentence in sentences if '(' not in sentence and ')' not in sentence]
    else:
        sentences = [sentence for sentence in sentences]

    result = " ".join(sentences)
    #print(result, type(result))
    return result

def simple_splitter(text, n=0):
    lines = text.split("\n")
    return lines[n]


####### text-to-speech #######
audio_file = 'speech.mp3'

voices = ['alloy', 'echo', 'fable', 'onyx', 'nova', 'shimmer']
response_formats = ["mp3", "flac", "aac", "opus"]


# Check if the file exists
if os.path.exists('openai_api_key.txt'):
    with open('openai_api_key.txt', 'r') as file:
        st.session_state.openai_api_key = file.read().strip()
        #st.session_state.openai_api_key = str(open('openai_api_key.txt', 'r').read())
else:
    st.session_state.openai_api_key = None


def text2speech(text,
                voice="nova",
                filename="speech.mp3",
                model="tts-1",
                speed=1,
                play=False):
    if os.path.exists(filename):
        os.remove(filename)

    client = OpenAI(api_key=st.session_state.openai_api_key)
    spoken_response = client.audio.speech.create(
        model=model, # tts-1 or tts-1-hd
        voice=voice,
        input=text,
        speed=speed
    )
    spoken_response.stream_to_file(filename)
    #.with_streaming_response.method()

def text2speech_stream(text,
                       voice="alloy",
                       model="tts-1",
                       speed=1,
                       play=False):
    client = OpenAI(api_key=st.session_state.openai_api_key)
    spoken_response = client.audio.speech.create(
        model=model,
        voice=voice,
        response_format="opus",
        input=text,
        speed=speed
    )

    # Create a buffer using BytesIO to store the data
    buffer = io.BytesIO()

    # Iterate through the 'spoken_response' data in chunks of 4096 bytes and write each chunk to the buffer
    for chunk in spoken_response.iter_bytes(chunk_size=4096):
        buffer.write(chunk)

    # Set the position in the buffer to the beginning (0) to be able to read from the start
    buffer.seek(0)

    if play:
        with sf.SoundFile(buffer, 'r') as sound_file:
            data = sound_file.read(dtype='int16')
            sd.play(data, sound_file.samplerate)
            sd.wait()
    return buffer


###################
# General parameters
api_models = ['gpt-4o-mini', 'gpt-4o', 'gpt-4o-2024-08-06']

# Initialize session state for persona traits
character_list   = ['none', 'hero', 'yoko', 'miguel', 'francois', 'julia', 'mike', 'penrose', 'leonardo', 'mendel', 'darwin','delamain']
personality_list = ['none', 'best_friend', 'intellectual', 'romantic', 'tsundere', 'yandere']
interest_list    = ['none', 'art_photo_cinema', 'nature_biology','alternative_music','gothic_darkness','nerd_gamer','glam_influencer']
language_list    = ['none', 'japanese', 'french','portuguese','italian', 'english']

voice_dict = {
    'none':'echo', 'hero':'echo', 'yoko':'nova', 'miguel':'echo', 'francois':'onyx', 'julia':'shimmer', 'mike':'onyx', 'penrose':'onyx', 'leonardo':'onyx', 'mendel':'onyx', 'darwin':'onyx','delamain':'onyx'
}

avatar_dict = {
    'none':"🤖", 'hero':"👦🏻", 'yoko':"👧🏻", 'miguel':"🧑🏼", 'francois':"🧑🏻", 'julia':"👱🏻‍♀️", 'mike':"👱🏻‍♂️", 'penrose':"👨🏻‍🏫", 'leonardo':"👨🏻‍🔬", 'mendel':"👨🏻‍⚕️", 'darwin':"👴🏻", 'delamain':"👨🏻‍💻"
}

if 'personality' not in st.session_state:
    st.session_state['personality'] = 'none'
if 'character' not in st.session_state:
    st.session_state['character'] = 'none'
if 'interest' not in st.session_state:
    st.session_state['interest'] = 'none'
if 'language_' not in st.session_state:
    st.session_state['language_'] = 'none'
### Premade characters ####
if st.session_state['character'] == 'yoko':
    st.session_state['personality'] = 'romantic'
    st.session_state['interest'] = 'nerd_gamer'
    st.session_state['language_'] = 'japanese'
if st.session_state['character'] == 'francois':
    st.session_state['personality'] = 'intellectual'
    st.session_state['interest'] = 'art_photo_cinema'
    st.session_state['language_'] = 'french'
if st.session_state['character'] == 'mike':
    st.session_state['personality'] = 'best_friend'
    st.session_state['interest'] = 'alternative_music'
    st.session_state['language_'] = 'english'
if st.session_state['character'] == 'miguel':
    st.session_state['personality'] = 'best_friend'
    st.session_state['interest'] = 'nature_biology'
    st.session_state['language_'] = 'portuguese'



######### Sidebar code #########
with st.sidebar:
    ### API KEY ###
    if not st.session_state.openai_api_key:
        st.session_state.openai_api_key = st.text_input("OpenAI API Key", key="chatbot_api_key", type="password")
    else:
        st.markdown("[API key provided]")

    #st.header('Section 2')
    #slider_value = st.slider('Select Range', 0, 100, 25)


    st.markdown("[Get an OpenAI API key](https://platform.openai.com/account/api-keys)")
    st.markdown("[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)")
    st.markdown("[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)")

    ### Choose Model ###
    #model = st.selectbox("GPT model", ['gpt-4o', 'gpt-3.5-turbo'])
    model = st.radio('Choose a model:', api_models)

    ### BUILD CHAR ###
    st.subheader('Build Your Character')
    # Create select box with the current value from session state
    get_character   = st.selectbox("**Character**", character_list,
                                   index= character_list.index(st.session_state['character']))

    #personality = st.selectbox("Personality", character_list)
    get_personality = st.selectbox("**Personality**", personality_list,
                                   index=personality_list.index(st.session_state['personality']))

    get_interest    = st.selectbox("**Interests**",   interest_list,
                                   index=interest_list.index(st.session_state['interest']))

    get_language    = st.selectbox("**Language**", language_list,
                                   index=language_list.index(st.session_state['language_']))

    user_avi = st.selectbox('Change your avatar', ['🧑🏻', '🧔🏻', '👩🏻', '👧🏻', '👸🏻','👱🏻‍♂️','🧑🏼','👸🏼','🧒🏽','👳🏽','👴🏼', '🎅🏻', ])

    #st.markdown("Update Persona after traits selection")
    #if st.button("Update Persona"):
    #    st.session_state["messages"] = update_persona(st.session_state["messages"])

    #st.markdown("Clear Chat to start again")
    # Add a button in the sidebar and assign the function to be executed on click
    if st.button("Clear Chat"):
        clearchat()

    st.session_state.audio_player = st.checkbox('Play Audio?')
    st.session_state.append_translator = st.checkbox('Translate reply?')


    ### Uploaders ###
    uploaded_file = st.file_uploader("Upload an text file", type=("txt", "md"))

    image_path = st.text_input("Load Image (path or url)")
    #image_file = st.file_uploader("Upload an image file", type=("jpg", "png"))
    def encode_image(image_path):
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')

    instructions = st.text_input("Add Instructions")



# Update session state with the selected value
st.session_state['character']   = get_character
st.session_state['personality'] = get_personality
st.session_state['interest']    = get_interest
st.session_state['language_']   = get_language

### Build Char ###
st.session_state.persona = f"""{characters[st.session_state['character']]} {personalities[st.session_state['personality']]} {interests[st.session_state['interest']]} \n {features['reply_style'][st.session_state['language_']]}"""

#characters[character]+personalities[personality]+interests[interest]+'\n'+features['reply_style'][language]


#### Append ###
if instructions:
    st.session_state["messages_assist"].append({"role": "system", "content": instructions})

if uploaded_file:
    text = uploaded_file.read().decode()
    st.session_state["messages"].append({"role": "system", "content": "Read the text below and add it's content to your knowledge:\n\n"+text})

#if uploaded_file:
    #image = uploaded_image.read().decode()
    #st.session_state["messages"] = ...



##################################################
##################################################

st.title("💬 GPT Chatbot")
st.caption("🚀 Your GPT Companion powered by OpenAI")
if "messages" not in st.session_state:
    #st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]
    st.session_state["messages"] = [{"role": "system", "content": st.session_state.persona}]
    st.session_state["messages_print"] = st.session_state["messages"]

# Update Persona Automatically
if st.session_state.persona not in st.session_state["messages"]:
    st.session_state["messages"] = update_persona(st.session_state["messages"])
    st.session_state["messages_print"] = st.session_state["messages"]

# Trigger the specific function based on the selection
#if assistant and not st.session_state["messages"] == [{"role": "system", "content": assistants[assistant]}]:
#    st.session_state["messages"] = [{"role": "system", "content": assistants[assistant]}]
#    #st.write('assistant changed')


### Chat Displayed ###
for msg in st.session_state["messages_print"]:
    if msg['role'] != 'system':
        if not isinstance(msg["content"], list):
            # Avatar
            if msg["role"] == 'user':
                avatar = user_avi
            else:
                avatar = avatar_dict[get_character]
            # Print Chat
            st.chat_message(msg["role"], avatar=avatar).write(msg["content"])


### Expand Chat ###
if prompt := st.chat_input():
    if not st.session_state.openai_api_key:
        st.info("Please add your OpenAI API key to continue.")
        st.stop()

    if image_path:
        if image_path.startswith('http'):
            print('<Image path:',image_path, '>')
            pass
        else:
            print('<Enconding Image...>')
            base64_image = encode_image(image_path)
            image_path = f"data:image/jpeg;base64,{base64_image}"

        image_add = {"role": 'user',
                     "content": [{"type": "image_url", "image_url": {"url": image_path} }] }
        #if image_add not in st.session_state["messages_assist"]:
            #st.session_state["messages_assist"].append(image_add)
        if image_add not in st.session_state["messages"]:
            st.session_state["messages"].append(image_add)

    client = OpenAI(api_key=st.session_state.openai_api_key)

    st.session_state["messages"].append({"role": "user", "content": prompt})
    st.session_state["messages_print"].append({"role": "user", "content": prompt})
    st.chat_message("user", avatar=user_avi).write(prompt)
    response = client.chat.completions.create(model=model, messages=st.session_state["messages"])
    msg_base = response.choices[0].message.content

    if st.session_state.append_translator:
        if st.session_state['language_'] == 'japanese':
            translator = create_jap_translator(rileva_lingua(prompt))
        else:
            translator = create_translator(rileva_lingua(prompt))
        translate_msg = [{"role": "system", "content": translator}]
        translate_msg.append({"role": "user", "content": msg_base})
        response = client.chat.completions.create(model=model, messages=translate_msg)
        #st.chat_message("assistant", avatar=avatar_dict[get_character]).write(response.choices[0].message.content)
        translation = response.choices[0].message.content
        #st.chat_message("assistant", avatar=avatar_dict[get_character]).write(translation)
        reply = msg_base
        msg = msg_base+"\n\n"+translation
    else:
        reply = msg_base
        msg = msg_base

    # Print Reply
    # Extracting only Language sentences without '(' or ')'
    #reply = simple_splitter(msg) #extract_foreign_sentences(msg, language=get_language)
    st.session_state["messages"].append({"role": "assistant", "content": msg_base})
    st.session_state["messages_print"].append({"role": "assistant", "content": msg})
    st.chat_message("assistant", avatar=avatar_dict[get_character]).write(msg)

    ######### Audio ######

    # Display and play the audio file
    if st.session_state.audio_player:
        if is_linux:
            #if not os.path.exists(audio_file):
            #    text2speech(' ', filename=audio_file)
            text2speech(reply, voice = voice_dict[get_character], filename=audio_file)
            audio_bytes = open(audio_file, 'rb').read()
            # Create a Streamlit audio player
            st.audio(audio_bytes, format='audio/mp3')
        else:
            buffer = text2speech_stream(reply, voice=voice_dict[get_character])
            st.audio(buffer, format='audio/ogg')



#%%

#from pychatgpt import copilot, copilotp, yoko, chat_thread, reply
###
#copilotp(""" In stremlit sidebar, make an internal subdivions of some elments , a sliding window  : """)






