from openai import OpenAI
import streamlit as st
from assistants import *

# Function to be executed on button click
def clearchat():
    st.session_state["messages"] = [{"role": "system", "content": st.session_state.assistant}]
    st.write("Chat cleared!")

# Sidebar code
with st.sidebar:
    openai_api_key = st.text_input("OpenAI API Key", key="chatbot_api_key", type="password")

    st.markdown("[Get an OpenAI API key](https://platform.openai.com/account/api-keys)")
    st.markdown("[View the source code](https://github.com/streamlit/llm-examples/blob/main/Chatbot.py)")
    st.markdown("[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://codespaces.new/streamlit/llm-examples?quickstart=1)")

    model = st.selectbox("GPT model", ['gpt-3.5-turbo', 'gpt-4o'])

    #assistant = st.selectbox("Assistant", ['yoko', 'hero','miguel','francois', 'penrose', 'mendel', 'julia', 'mike'])
    character = st.selectbox("Character", ['none', 'hero', 'yoko', 'miguel', 'francois', 'julia', 'mike', 'penrose', 'leonardo', 'mendel', 'darwin','delamain'])
    personality = st.selectbox("Personality", ['none', 'bestie', 'intellectual', 'romantic', 'tsundere', 'yandere'])
    nationality = st.selectbox("Nationality", ['none', 'japanese', 'french','portuguese','italian', 'english'])
    st.markdown("Press Clearchat after assistant selection")

    # Add a button in the sidebar and assign the function to be executed on click
    if st.button("Clearchat"):
        clearchat()

    user_avi = st.selectbox("Change your avatar", ['🧑🏻', '🧔🏻', '👩🏻', '👧🏻', '👸🏻','👱🏻‍♂️','🧑🏼','👸🏼','🧒🏽','👳🏽','👴🏼', '🎅🏻', ])
    uploaded_file = st.file_uploader("Upload an text file", type=("txt", "md"))
    #uploaded_image = st.file_uploader("Upload an image file", type=("png", "jpg"))
    image_url = st.text_input("Image Url")

if uploaded_file:
    text = uploaded_file.read().decode()
    st.session_state["messages"].append({"role": "system", "content": "Read the text below and add it's content to your knowledge:\n\n"+text})

#if uploaded_file:
    #image = uploaded_image.read().decode()
    #st.session_state["messages"] = ...

avatart_dict = {
    'none':"🤖", 'hero':"👦🏻", 'yoko':"👧🏻", 'miguel':"🧑🏼", 'francois':"🧑🏻", 'julia':"👱🏻‍♀️", 'mike':"👱🏻‍♂️", 'penrose':"👨🏻‍🏫", 'leonardo':"👨🏻‍🔬", 'mendel':"👨🏻‍⚕️", 'darwin':"👴🏻", 'delamain':"👨🏻‍💻"
}


# Build assistant
nationality = features['reply_type'][nationality]
st.session_state.assistant = characters[character]+personalities[personality]+'\n'+nationality

st.title("💬 GPT Chatbot")
st.caption("🚀 A GPT Companion powered by OpenAI")
if "messages" not in st.session_state:
    #st.session_state["messages"] = [{"role": "assistant", "content": "How can I help you?"}]
    st.session_state["messages"] = [{"role": "system", "content": st.session_state.assistant}]


# Trigger the specific function based on the selection
#if assistant and not st.session_state["messages"] == [{"role": "system", "content": assistants[assistant]}]:
#    st.session_state["messages"] = [{"role": "system", "content": assistants[assistant]}]
#    #st.write('assistant changed')


for msg in st.session_state.messages:
    if msg['role'] != 'system':
        if not isinstance(msg["content"], list):
            if msg["role"] == 'user':
                avatar = user_avi
            else:
                avatar = avatart_dict[character]
            st.chat_message(msg["role"], avatar=avatar).write(msg["content"])


if prompt := st.chat_input():
    openai_api_key = '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'
    if not openai_api_key:
        st.info("Please add your OpenAI API key to continue.")
        st.stop()

    if image_url:
        image_add = {"role": 'user',
                     "content": [{"type": "image_url", "image_url": {"url": image_url} }] }
        if image_add not in st.session_state["messages"]:
            st.session_state["messages"].append(image_add)

    client = OpenAI(api_key=openai_api_key)
    st.session_state.messages.append({"role": "user", "content": prompt})
    st.chat_message("user", avatar=user_avi).write(prompt)
    response = client.chat.completions.create(model=model, messages=st.session_state.messages)
    msg = response.choices[0].message.content
    print(model)
    print(msg)
    st.session_state.messages.append({"role": "assistant", "content": msg})
    st.chat_message("assistant", avatar=avatart_dict[character]).write(msg)


#%%

